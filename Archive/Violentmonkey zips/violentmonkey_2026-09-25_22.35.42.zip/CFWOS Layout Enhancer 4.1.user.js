// ==UserScript==
// @name         CFWOS Layout Enhancer 4.1
// @version      4.1e(Dark mode update)
// @description  Restore and enhance AWOS report layout with full styling
// @author       Chris
// @match        https://met.forces.gc.ca/*
// @match        http://localhost/english/AWOS/*
// @grant        none
// ==/UserScript==

(function () {



  'use strict';

  if (window.Logger) return;

  window.Logger = {

    log(...args) {
      console.log('🟢%c', 'color: #00bfff; font-weight: bold;', ...args);
    },

    group(name, fn) {
      console.groupCollapsed(`📂%c[Group] ${name}`, 'color: #00bfff; font-weight: bold;');
      try { fn(); } catch (e) {
        console.error('[Logger.group] ❌ group error:', e);
      }
      console.groupEnd();
    },
    error(...args) {
      console.error('%c[ERROR] ❌', 'color: red; font-weight: bold;', ...args);
    },
    warn(...args) {
      console.warn('%c[WARN] ⚠️', 'color: orange; font-weight: bold;', ...args);
    },
    info(...args) {
      console.info('%c[INFO] ℹ️', 'color: green; font-weight: bold;', ...args);
    },
    debug(...args) {
      if (window.AWOS_DEBUG) {
        console.debug('%c[DEBUG] 🐞', 'color: gray; font-weight: bold;', ...args);
      }
    },
    perf(action = 'start', overrideLabel = null, defaultLabel = 'Script', ...args) {
      let label = overrideLabel || defaultLabel;

      // Only try to auto-detect if no override provided
      if (!overrideLabel) {
        try {
          const err = new Error();
          const stackLines = err.stack.split('\n');

          // stackLines[0] = "Error"
          // stackLines[1] = "    at Logger.perf ..."
          // stackLines[2] = "    at FunctionName ..." or "    at Object.methodName ..."
          const callerLine = stackLines[2] || '';
          const match = callerLine.match(/at\s+(.*?)\s*\(/);
          if (match && match[1]) {
            label = match[1].trim();
          }
        } catch {
          // ignore, fallback to defaultLabel
        }
      }

      this._perfTimes = this._perfTimes || {};

      if (action.toLowerCase() === 'start') {
        this._perfTimes[label] = performance.now();
        this.log(`⏱️ [${label}] start ${this._perfTimes[label].toFixed(3)} ms`);
      }
      else if (action.toLowerCase() === 'stop') {
        const now = performance.now();
        let duration = now;

        if (this._perfTimes[label]) {
          duration = now - this._perfTimes[label];
          delete this._perfTimes[label];
        }
        this._perfTimes[label] = now;
        this.log(`[${label}] finished ${now.toFixed(3)} ms - took ${duration.toFixed(3)} ms`);
      }
      else {
        this.warn(`[Logger.perf] Unknown action "${action}". Use "start" or "stop".`);
      }
    },
    perfWrap(fn, overrideLabel = null) {
      if (typeof fn !== 'function') {
        this.warn('[Logger.perfWrap] First argument must be a function');
        return;
      }
      const label = overrideLabel || fn.name || 'anonymous';
      return (...args) => {
        this.perf('start', label);
        const result = fn.apply(this, args);
        if (result instanceof Promise) {
          return result.finally(() => this.perf('stop', label));
        }
        this.perf('stop', label);
        return result;
      };
    },
    perfTimeMark(label) {
      this._perfTimeMarks = this._perfTimeMarks || {};
      const now = performance.now();
      if (!this._perfTimeMarks[label]) {
        this._perfTimeMarks[label] = now;
        this.log(`📍[${label}] time mark set at ${now.toFixed(3)} ms`);

      } else {
        const duration = now - this._perfTimeMarks[label];
        this.log(`📍[${label}] +${duration.toFixed(3)} ms since last time mark`);

        this._perfTimeMarks[label] = now;
      }
    }

  };
  Logger.modules = {
    ready: {},
    queue: [],
    register(name) {
      if (this.ready[name]) {
        Logger.warn(`[Logger.Module.register] "${name}" already registered — ignoring duplicate.`);
        return;
      }
      this.ready[name] = true;
      Logger.log(`[Logger.Module.Ready] Module registered: ${name}`);

      if (this.queue[name]) {
        this.queue[name].forEach(cb => cb());
        delete this.queue[name];
      }
      // Check queued callbacks
      this.queue = this.queue.filter(({ deps, fn }) => {
        if (deps.every(dep => this.ready[dep])) {
          try {
            fn();
          } catch (e) {
            Logger.error(`[Logger.modules.queue] Error running module callback for ${name}:`, e);
          }
          return false; // remove from queue
        }
        return true;
      });
    },
    whenReady(deps, fn) {
      if (deps.every(dep => this.ready[dep])) {
        fn();
      } else {
        this.queue.push({ deps, fn });
      }
    }
  };

  // --- Perf table collector ---
  const perfRecords = [];

  // Wrap existing perf
  const _origPerf = Logger.perf;
  Logger.perf = function (action = 'start', overrideLabel = null, defaultLabel = 'Script') {
    // Call the original logic (keeps auto-label + console output)
    _origPerf.call(this, action, overrideLabel, defaultLabel);

    // Also record for summary table
    const label = overrideLabel || defaultLabel;
    if (action.toLowerCase() === 'start') {
      perfRecords.push({ type: 'perf', label, start: performance.now(), end: null, duration: null });
    } else if (action.toLowerCase() === 'stop') {
      const rec = [...perfRecords].reverse().find(r => r.type === 'perf' && r.label === label && r.end === null);
      if (rec) {
        rec.end = performance.now();
        rec.duration = rec.end - rec.start;
      }
    }
  };

  // Wrap existing perfWrap
  const _origPerfWrap = Logger.perfWrap;
  Logger.perfWrap = function (fn, overrideLabel = null) {
    const label = overrideLabel || fn.name || 'anonymous';
    return _origPerfWrap.call(this, function (...args) {
      const start = performance.now();
      perfRecords.push({ type: 'perfWrap', label, start, end: null, duration: null });
      try {
        return fn.apply(this, args);
      } finally {
        const end = performance.now();
        const rec = [...perfRecords].reverse().find(r => r.type === 'perfWrap' && r.label === label && r.end === null);
        if (rec) {
          rec.end = end;
          rec.duration = rec.end - rec.start;
        }
      }
    }, label);
  };

  // Wrap existing perfMark
  const _origPerfTimeMark = Logger.perfTimeMark;
  Logger.perfTimeMark = function (label) {
    _origPerfTimeMark.call(this, label); // keep console output
    perfRecords.push({ type: 'perfTimeMark', label, time: performance.now() });
  };

  // Dump table after everything has loaded
  Logger.modules.whenReady(['core', 'cleanup', 'layout'], () => {
    Logger.info("📊[Logger.modules.whenReady] Dumping performance table after page load");

    if (perfRecords.length) {
      const filtered = perfRecords.filter((rec, idx, arr) => {
        if (rec.type === 'perf') {
          return !arr.some(r =>
            r.type === 'perfWrap' &&
            r.label === rec.label &&
            Math.abs((r.start || 0) - (rec.start || 0)) < 1
          );
        }
        return true;
      });

      const sorted = [...filtered].sort((a, b) => {
        const aTime = a.type === 'perfTimeMark' ? a.time : a.start;
        const bTime = b.type === 'perfTimeMark' ? b.time : b.start;
        return (aTime || 0) - (bTime || 0);
      });

      console.table(sorted.map(r => ({
        Type: r.type,
        Label: r.label,
        Start: r.start?.toFixed?.(2) || '',
        End: r.end?.toFixed?.(2) || '',
        Duration: r.duration ? r.duration.toFixed(2) + ' ms' : '',
        Time: r.type === 'perfTimeMark'
          ? r.time.toFixed(2) + ' ms'
          : ''
      })));
    }
  });
})();

(function () {
  'use strict';

  const DEBUG_MODE = false;
  let layoutApplied = false;

  function findAwosPanel() {
    return document.querySelector('#awos, #awos-panel, .awos-report, .report-panel, main');
  }
  function applyEnhancements(awosPanel) {
    const isDark = window.awosDarkMode;

    Object.assign(awosPanel.style, {
      backgroundColor: isDark ? '#1e1e1e' : '#f5f5dc',
      color: isDark ? '#e0e0e0' : '#222',
      padding: '20px',
      borderRadius: '10px',
      boxShadow: isDark ? '0 2px 12px rgba(0,0,0,0.5)' : '0 2px 12px rgba(0,0,0,0.15)',
      fontFamily: '"Segoe UI", sans-serif',
      lineHeight: '1.4',
      fontSize: '13px',
    });

    awosPanel.querySelectorAll('h1, h2, h3').forEach(header => {
      header.style.color = isDark ? '#ccc' : '#333';
      header.style.borderBottom = isDark ? '1px solid #555' : '1px solid #ccc';
      header.style.paddingBottom = '6px';
      header.style.marginTop = '20px';
    });

    awosPanel.querySelectorAll('table').forEach(table => {
      Object.assign(table.style, {
        backgroundColor: isDark ? '#2a2a2a' : '#fff',
        color: isDark ? '#ddd' : '#000',
        borderCollapse: 'collapse',
        width: '100%',
        marginTop: '20px',
        border: isDark ? '1px solid #444' : '1px solid #ccc',
      });

      table.querySelectorAll('th, td').forEach(cell => {
        Object.assign(cell.style, {
          backgroundColor: isDark ? '#2c2c2c' : '#fdf6e3',
          color: isDark ? '#eee' : '#333',
          border: isDark ? '1px solid #555' : '1px solid #ccc',
          padding: '8px',
          textAlign: 'center',
        });
      });
    });
  }
  function applyDarkModeStyles(forcedMode = null, context = '', forceSource = null) {
    // Decide the mode to apply
    const isDark = forcedMode !== null ? forcedMode : window.awosDarkMode;
    window.awosDarkMode = isDark; // keep global in sync

    const awosPanel = findAwosPanel();
    const topBar = document.querySelector('#awos-top-bar');
    const buttons = topBar?.querySelectorAll('button');

    // Body styling
    Object.assign(document.body.style, {
      backgroundColor: isDark ? '#121212' : '',
      color: isDark ? '#e0e0e0' : '',
    });

    // Top bar styling
    if (topBar) {
      Object.assign(topBar.style, {
        backgroundColor: isDark ? '#1f1f1f' : '#ffffff',
        borderBottom: isDark ? '1px solid #333' : '1px solid #ccc',
        boxShadow: isDark ? '' : 'rgba(0, 0, 0, 0.05) 0px 2px 4px',
        position: 'sticky',
        top: '0',
        zIndex: '1000'
      });
    }

    // Button styling (unchanged)
    buttons?.forEach(btn => {
        const label = btn.textContent?.trim();
        // Auto-refresh button (special case: paused)
        if (label?.includes('Auto-Refresh')) {
          const refreshStatus = window.getAwosRefreshStatus?.();
          if (refreshStatus) {
            const bgColor = refreshStatus.enabled
              ? (isDark ? '#444' : '#0078D4')
              : (isDark ? '#996600' : '#ffef08');
            const textColor = refreshStatus.enabled
              ? '#ffffff'
              : (isDark ? '#f0f0f0' : '#000000');
            styleButton(btn, bgColor, { color: textColor });
          }
          return;
        }

        // Debug button — preserve layout, change colors
        if (label === '🧪 Debug') {
          const bgColor = isDark ? '#000000' : '#000000'; // Keep black background
          const textColor = isDark ? '#00ff00' : '#00ff00'; // Always green
          styleButton(btn, bgColor, {
            color: textColor,
            fontFamily: 'monospace'
          });
          return;
        }

        // Reset Floater — preserve layout, change background
        if (label === '🧹 Reset Floater') {
          const bgColor = isDark ? '#8B0000' : '#cc0000';
          styleButton(btn, bgColor, {
            color: '#ffffff'
          });
          return;
        }

        // Report Viewer — standard theme-aware styling
        if (label === '📊 Report Viewer') {
          styleButton(btn); // Uses theme-aware background and white text
          return;
        }

        // New Stations button
        const newStationsBtn = document.querySelector('#base_id');
        if (newStationsBtn) {
          styleButton(newStationsBtn, getUnifiedButtonColor(), {
            marginLeft: '24px',
            margin: '0 auto',
            display: 'block',
            textAlign: 'center',
            boxSizing: 'border-box',
            flex: 'none'
          });
          if(DEBUG_MODE) {
            newStationsBtn.style.border = '3px dashed red';
          };
        }

        // Default styling for all other buttons
        styleButton(btn); // Uses theme-aware background and white text
      });

    // AWOS panel styling
    if (awosPanel) {
      applyEnhancements(awosPanel);
    } else {
      Logger.warn('⚠️ AWOS panel not found — dark mode styling skipped');
    }

    // Determine source
    let source;
    if (forceSource) {
      source = forceSource;
    } else {
      switch (window.awosDarkModeType) {
        case 'light':
        case 'dark':
          source = 'via Manual Toggle';
          break;
        case 'auto':
          source = 'via Auto Switch';
          break;
        case 'default':
        default:
          source = 'via Default Mode';
      }
    }

    const prefix = context ? `[${context}] ` : '';

    Logger.info(
      isDark
        ? `${prefix}🌙 Dark mode is ON (${source}) — applying dark styles`
        : `${prefix}☀️ Dark mode is OFF (${source})`
    );
  }

  window.applyDarkModeStyles = applyDarkModeStyles;
  Logger.modules.whenReady(['core'], () => {
    Logger.modules.whenReady(['cleanup'], () => {
      if (layoutApplied) return; // <-- prevent double-run
      let attempts = 0;
      const maxAttempts = 20;
      const interval = 100;
      const tryEnhance = () => {
        if (layoutApplied) return; // <-- prevent re-entry mid-loop
        const awosPanel = findAwosPanel();
        if (awosPanel) {
          Logger.info('🎨 Running Layout Enhancer after Cleanup');
          applyEnhancements(awosPanel);
          // If an override is active, force the source to Manual Toggle
          let initialSource = null;
          switch (window.awosDarkModeType) {
            case 'light':
            case 'dark':
              initialSource = 'via Manual Toggle';
              break;
            case 'auto':
              initialSource = 'via Auto Switch';
              break;
            case 'default':
            default:
              initialSource = 'via Default Mode';
          }
          applyDarkModeStyles(null, 'Initial Button State', initialSource);
          layoutApplied = true; // <-- mark as done
          Logger.modules.register('layout');
          return;
        }
        attempts++;
        if (attempts <= maxAttempts) {
          setTimeout(tryEnhance, interval);
        } else {
          Logger.warn('⚠️ AWOS container not found after cleanup (tried 2s). Skipping layout.');
        }
      };
      tryEnhance();
    });
  });

})();