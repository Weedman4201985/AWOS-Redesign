// ==UserScript==
// @name         WET Plugin Override + Remote Logging
// @namespace    http://tampermonkey.net/
// @version      1.3
// @description  Suppress unused WET plugins and log activity remotely
// @match        https://met.forces.gc.ca/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function waitForDependencies() {
  if (typeof jQuery === "undefined") {
    console.log("Waiting for jQuery...");
    setTimeout(waitForDependencies, 250);
    return;
  }

  (function($, window, document) {
    "use strict";

    const debugMode = true;
    const remoteLogURL = "https://your-logging-endpoint.example.com/log"; // 🔧 Replace with your endpoint

    function logRemote(message, context = {}) {
      if (!remoteLogURL) return;
      const payload = {
        timestamp: new Date().toISOString(),
        message,
        url: window.location.href,
        ...context
      };
      fetch(remoteLogURL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      }).catch(err => console.warn("Remote log failed:", err));
    }

    // ✅ Suppress unused WET plugins
    const suppressedPlugins = [
      "wb-inview", "wb-mltmd", "wb-lbx", "wb-calevt",
      "wb-charts", "wb-twitter", "wb-zebra", "wb-txthl", "wb-toggle"
    ];
    suppressedPlugins.forEach(plugin => {
      $(document).on(`wb-init.${plugin}`, function(event) {
        event.stopImmediatePropagation();
        if (debugMode) console.log("Suppressed unused plugin:", plugin);
        logRemote("Suppressed plugin", { plugin });
      });
    });

    // ✅ Log all plugin init attempts
    if (debugMode) {
      $(document).on("wb-init", function(event) {
        console.log("Plugin initialized:", event.namespace, event.target);
        logRemote("Plugin initialized", { plugin: event.namespace });
      });
    }

    // ✅ Prevent jQuery UI dialog/datepicker from initializing
    $.fn.dialog = function() {
      if (debugMode) console.warn("dialog() suppressed");
      logRemote("dialog() suppressed");
      return this;
    };
    $.fn.datepicker = function() {
      if (debugMode) console.warn("datepicker() suppressed");
      logRemote("datepicker() suppressed");
      return this;
    };

    // ✅ Safe Dojo widget cleanup
    if (window.dijit && dijit.registry && typeof dijit.registry.forEach === "function") {
      dijit.registry.forEach(function(widget) {
        if (!widget.domNode || !widget.domNode.offsetParent) {
          widget.destroyRecursive();
          if (debugMode) console.log("Destroyed unused Dojo widget:", widget.id);
          logRemote("Destroyed Dojo widget", { widgetId: widget.id });
        }
      });
    } else {
      if (debugMode) console.log("Dojo not active or registry unavailable — skipping cleanup.");
      logRemote("Dojo registry unavailable");
    }

    // ✅ Patch legacy styles
    const style = document.createElement("style");
    style.textContent = `
      .wb-zebra tr:nth-child(even) { background: none !important; }
      [data-wb-lbx] { display: none !important; }
      table.wb-tables { border-collapse: collapse; width: 100%; }
    `;
    document.head.appendChild(style);

    // ✅ Cleanup hidden overlays
    setTimeout(() => {
      $(".wb-overlay").each(function() {
        if (!$(this).is(":visible")) {
          $(this).remove();
          if (debugMode) console.log("Removed hidden overlay:", this.id);
          logRemote("Removed hidden overlay", { overlayId: this.id });
        }
      });
    }, 3000);

    // ✅ Visual badge to confirm script is active
    document.addEventListener("DOMContentLoaded", function() {
      const badge = document.createElement("div");
      badge.textContent = "Override Active";
      badge.style.cssText = `
        position: fixed;
        bottom: 10px;
        right: 10px;
        background: #222;
        color: #fff;
        padding: 5px 10px;
        font-size: 12px;
        z-index: 9999;
        border-radius: 4px;
        box-shadow: 0 0 5px rgba(0,0,0,0.3);
      `;
      document.body.appendChild(badge);
    });

  })(jQuery, window, document);
})();
